function joinus(){
    window.location.href = 'joinus.php';
}

function developers() {
    window.location.href = "developers.php";
}
function mailschool(){
    window.location.href = "mailto:pashupati.school4012@gmail.com";
}

function locationmap(){
    window.location.href = "https://maps.app.goo.gl/seKbXLuVfkg5oViM9";
}

function callschool(){  
    window.location.href = "tel:9844640316";
}

function ministryofEducation(){
    window.location.href = "https://moest.gov.np/";

}
function curriculumDevelopmentCentre(){
    window.location.href = "https://moecdc.gov.np/en";

}
function ePustakalaya(){
    window.location.href = "https://pustakalaya.org/en/";

}

