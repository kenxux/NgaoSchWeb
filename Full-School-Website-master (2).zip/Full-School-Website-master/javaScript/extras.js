function nepalicalender(){
    window.location.href = "calender.php";
}
function schoolroutine(){
    window.location.href = "schoolroutine.php";
}
function staffs(){
    window.location.href = "staffs.php";
}
function gallery(){
    window.location.href = "albums.php";
}
