// <!-- Developers Details -->


// <!-- Nishchal Acharya -->

function nishchal_linkedin() {
    window.location.href = 'https://www.linkedin.com/in/nishchalacharya/';
}
function nishchal_twitter() {
    window.location.href = 'https://twitter.com/nishchal_acc';

}
function nishchal_portfolio() {
    window.location.href = 'https://nishchalacharya.com.np/';
}

// <!-- Pratik Ghimire -->
function pratik_facebook() {
    window.location.href = 'https://www.linkedin.com/in/nishchalacharya/';
}
function pratik_twitter() {
    window.location.href = 'https://twitter.com/nishchal_acc';

}
function pratik_whatsapp() {
    window.location.href = 'https://nishchalacharya.com.np/';
}

// <!-- Sugam Rai -->
function sugam_facebook() {
    window.location.href = 'https://www.linkedin.com/in/nishchalacharya/';
}
function sugam_whatsapp() {
    window.location.href = 'https://twitter.com/nishchal_acc';

}

// <!-- Monika Rajbanshi -->
function monika_facebook() {
    window.location.href = 'https://nishchalacharya.com.np/';
}
function monika_whatsapp() {
    window.location.href = 'https://www.linkedin.com/in/nishchalacharya/';
}
